<?php
$username="root";
$password="";
$server='localhost';
$db='contactform';

$con=mysqli_connect($server,$username,$password,$db);
// if($con){
// ?>
// <script>
//     alert('connection successfully!');
// </script>

// <?php
// }





?>